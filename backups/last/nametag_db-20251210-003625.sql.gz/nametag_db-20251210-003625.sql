--
-- PostgreSQL database dump
--

\restrict 9sLqRyR9EUNpru83WZwaSclivYt8O1l6JocKfk9mc2WhwJ4OSwfbeN6H87KsU7D

-- Dumped from database version 16.11
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DateFormat; Type: TYPE; Schema: public; Owner: nametag
--

CREATE TYPE public."DateFormat" AS ENUM (
    'MDY',
    'DMY',
    'YMD'
);


ALTER TYPE public."DateFormat" OWNER TO nametag;

--
-- Name: ReminderIntervalUnit; Type: TYPE; Schema: public; Owner: nametag
--

CREATE TYPE public."ReminderIntervalUnit" AS ENUM (
    'WEEKS',
    'MONTHS',
    'YEARS'
);


ALTER TYPE public."ReminderIntervalUnit" OWNER TO nametag;

--
-- Name: ReminderType; Type: TYPE; Schema: public; Owner: nametag
--

CREATE TYPE public."ReminderType" AS ENUM (
    'ONCE',
    'RECURRING'
);


ALTER TYPE public."ReminderType" OWNER TO nametag;

--
-- Name: Theme; Type: TYPE; Schema: public; Owner: nametag
--

CREATE TYPE public."Theme" AS ENUM (
    'LIGHT',
    'DARK'
);


ALTER TYPE public."Theme" OWNER TO nametag;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: nametag
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO nametag;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: nametag
--

CREATE TABLE public.groups (
    id text NOT NULL,
    "userId" text NOT NULL,
    name text NOT NULL,
    description text,
    color text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.groups OWNER TO nametag;

--
-- Name: important_dates; Type: TABLE; Schema: public; Owner: nametag
--

CREATE TABLE public.important_dates (
    id text NOT NULL,
    "personId" text NOT NULL,
    title text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "reminderEnabled" boolean DEFAULT false NOT NULL,
    "reminderType" public."ReminderType",
    "reminderInterval" integer,
    "reminderIntervalUnit" public."ReminderIntervalUnit",
    "lastReminderSent" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.important_dates OWNER TO nametag;

--
-- Name: people; Type: TABLE; Schema: public; Owner: nametag
--

CREATE TABLE public.people (
    id text NOT NULL,
    "userId" text NOT NULL,
    name text NOT NULL,
    surname text,
    nickname text,
    "lastContact" timestamp(3) without time zone,
    notes text,
    "relationshipToUserId" text,
    "contactReminderEnabled" boolean DEFAULT false NOT NULL,
    "contactReminderInterval" integer,
    "contactReminderIntervalUnit" public."ReminderIntervalUnit",
    "lastContactReminderSent" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.people OWNER TO nametag;

--
-- Name: person_groups; Type: TABLE; Schema: public; Owner: nametag
--

CREATE TABLE public.person_groups (
    "personId" text NOT NULL,
    "groupId" text NOT NULL,
    "addedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.person_groups OWNER TO nametag;

--
-- Name: relationship_types; Type: TABLE; Schema: public; Owner: nametag
--

CREATE TABLE public.relationship_types (
    id text NOT NULL,
    "userId" text,
    name text NOT NULL,
    label text NOT NULL,
    color text,
    "inverseId" text,
    "isDefault" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.relationship_types OWNER TO nametag;

--
-- Name: relationships; Type: TABLE; Schema: public; Owner: nametag
--

CREATE TABLE public.relationships (
    id text NOT NULL,
    "personId" text NOT NULL,
    "relatedPersonId" text NOT NULL,
    "relationshipTypeId" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.relationships OWNER TO nametag;

--
-- Name: users; Type: TABLE; Schema: public; Owner: nametag
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    surname text,
    nickname text,
    theme public."Theme" DEFAULT 'DARK'::public."Theme" NOT NULL,
    "dateFormat" public."DateFormat" DEFAULT 'MDY'::public."DateFormat" NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "emailVerifyToken" text,
    "emailVerifyExpires" timestamp(3) without time zone,
    "emailVerifySentAt" timestamp(3) without time zone,
    "passwordResetToken" text,
    "passwordResetExpires" timestamp(3) without time zone,
    "passwordResetSentAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO nametag;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: nametag
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
61e5cc2e-3e14-4bda-8efa-4317b65eb0ec	38aae08d1870ff9e222c55993499909dd50a634bf3b98ad79717d421bd87312f	2025-12-07 22:07:48.254804+00	20251207220415_init	\N	\N	2025-12-07 22:07:48.227021+00	1
31b2c85f-ece0-48e8-95b5-3e4a89c204c4	3fccd58f0892b6ba4e8f3442b46f13361773ee73867038b50784c91be264e1dd	2025-12-07 22:26:27.618553+00	20251207222627_change_default_theme_to_dark	\N	\N	2025-12-07 22:26:27.615909+00	1
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: nametag
--

COPY public.groups (id, "userId", name, description, color, "createdAt", "updatedAt") FROM stdin;
cmixkx0tc000bjwmjya5ll0bp	cmixkx0s10000jwmjo82b5r2w	Family	Family members	#EF4444	2025-12-08 20:03:28.992	2025-12-08 20:03:28.992
cmixkx0te000cjwmjm6ekbv46	cmixkx0s10000jwmjo82b5r2w	Friends	Close friends	#3B82F6	2025-12-08 20:03:28.994	2025-12-08 20:03:28.994
cmixkx0tf000djwmjrnmcovre	cmixkx0s10000jwmjo82b5r2w	Work	Colleagues and professional contacts	#10B981	2025-12-08 20:03:28.995	2025-12-08 20:03:28.995
cmixmexrs000644mj4wi3i3j1	cmixkzil3000244mjbi2dj8hc	Cabras Sobre Ruedas	\N	#F59E0B	2025-12-08 20:45:24.472	2025-12-08 20:45:24.472
cmiygdmqq000044lnj3bxxxoe	cmixkzil3000244mjbi2dj8hc	CSR VIP	\N	#EF4444	2025-12-09 10:44:12.002	2025-12-09 10:44:12.002
cmiykjqi3000144ln2o8iwr1e	cmixkzil3000244mjbi2dj8hc	Chobis	\N	#10B981	2025-12-09 12:40:55.275	2025-12-09 12:40:55.275
cmiykjqil000244ln8f2rqgg4	cmixkzil3000244mjbi2dj8hc	UDA	Compañeros de Ingeniería de Software	#3B82F6	2025-12-09 12:40:55.293	2025-12-09 12:40:55.293
\.


--
-- Data for Name: important_dates; Type: TABLE DATA; Schema: public; Owner: nametag
--

COPY public.important_dates (id, "personId", title, date, "reminderEnabled", "reminderType", "reminderInterval", "reminderIntervalUnit", "lastReminderSent", "createdAt", "updatedAt") FROM stdin;
cmixkx0tt000fjwmjxhwjoe11	cmixkx0ts000ejwmjsvzyfc7g	Birthday	1985-03-15 00:00:00	f	\N	\N	\N	\N	2025-12-08 20:03:29.007	2025-12-08 20:03:29.007
cmixkx0tz000hjwmjdpc4grck	cmixkx0ty000gjwmj9rl6gwa9	Birthday	1987-07-22 00:00:00	f	\N	\N	\N	\N	2025-12-08 20:03:29.013	2025-12-08 20:03:29.013
cmixkx0u4000jjwmjyun9ourd	cmixkx0u3000ijwmjkxgw63cj	Birthday	2015-05-10 00:00:00	f	\N	\N	\N	\N	2025-12-08 20:03:29.018	2025-12-08 20:03:29.018
cmixkx0ua000ljwmj5s7kiymc	cmixkx0u9000kjwmj5c68n8u2	Birthday	2018-09-03 00:00:00	f	\N	\N	\N	\N	2025-12-08 20:03:29.025	2025-12-08 20:03:29.025
cmixkx0ue000njwmj2itsprx7	cmixkx0ud000mjwmj3cq37lvu	Birthday	1990-01-18 00:00:00	f	\N	\N	\N	\N	2025-12-08 20:03:29.029	2025-12-08 20:03:29.029
cmixkx0ui000pjwmjbjkof5ie	cmixkx0uh000ojwmjoo2gclkx	Birthday	1988-11-30 00:00:00	f	\N	\N	\N	\N	2025-12-08 20:03:29.033	2025-12-08 20:03:29.033
cmixkx0um000rjwmjmjbuhnc0	cmixkx0ul000qjwmjghfen95l	Birthday	1983-06-12 00:00:00	f	\N	\N	\N	\N	2025-12-08 20:03:29.037	2025-12-08 20:03:29.037
\.


--
-- Data for Name: people; Type: TABLE DATA; Schema: public; Owner: nametag
--

COPY public.people (id, "userId", name, surname, nickname, "lastContact", notes, "relationshipToUserId", "contactReminderEnabled", "contactReminderInterval", "contactReminderIntervalUnit", "lastContactReminderSent", "createdAt", "updatedAt") FROM stdin;
cmixkx0ts000ejwmjsvzyfc7g	cmixkx0s10000jwmjo82b5r2w	John	Smith	\N	2024-11-25 00:00:00	My brother. Works as a software engineer. Phone: +1 (555) 123-4567. Address: 123 Main St, Springfield, IL	cmixkx0sd0003jwmj9nh201wy	f	\N	\N	\N	2025-12-08 20:03:29.007	2025-12-08 20:03:29.007
cmixkx0ty000gjwmj9rl6gwa9	cmixkx0s10000jwmjo82b5r2w	Sarah	Johnson	\N	2024-11-20 00:00:00	John's wife. Teacher at elementary school. Phone: +1 (555) 234-5678. Address: 123 Main St, Springfield, IL	cmixkx0sp0009jwmjcm4l356m	f	\N	\N	\N	2025-12-08 20:03:29.013	2025-12-08 20:03:29.013
cmixkx0u3000ijwmjkxgw63cj	cmixkx0s10000jwmjo82b5r2w	Emma	Smith	\N	\N	John and Sarah's daughter. Loves reading and drawing.	cmixkx0sp0009jwmjcm4l356m	f	\N	\N	\N	2025-12-08 20:03:29.018	2025-12-08 20:03:29.018
cmixkx0u9000kjwmj5c68n8u2	cmixkx0s10000jwmjo82b5r2w	Lucas	Smith	\N	\N	John and Sarah's son. Plays soccer.	cmixkx0sp0009jwmjcm4l356m	f	\N	\N	\N	2025-12-08 20:03:29.025	2025-12-08 20:03:29.025
cmixkx0ud000mjwmj3cq37lvu	cmixkx0s10000jwmjo82b5r2w	Mike	Chen	\N	2024-11-28 00:00:00	Best friend from college. Software developer at TechCorp. Phone: +1 (555) 345-6789	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-08 20:03:29.029	2025-12-08 20:03:29.029
cmixkx0uh000ojwmjoo2gclkx	cmixkx0s10000jwmjo82b5r2w	Jessica	Martinez	\N	2024-11-15 00:00:00	Colleague from work. Project manager. Email: jessica@example.com. Phone: +1 (555) 456-7890	cmixkx0sl0007jwmj4s6b2lxk	f	\N	\N	\N	2025-12-08 20:03:29.033	2025-12-08 20:03:29.033
cmixkx0ul000qjwmjghfen95l	cmixkx0s10000jwmjo82b5r2w	David	Brown	\N	2024-10-20 00:00:00	Neighbor and friend. Architect. Phone: +1 (555) 567-8901	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-08 20:03:29.037	2025-12-08 20:03:29.037
cmixlaiz6000544mj7xl1qqrs	cmixkzil3000244mjbi2dj8hc	Roberto	Pacios	\N	\N	\N	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-08 20:13:59.05	2025-12-08 20:45:34.865
cmixmtkj8000a44mju9jvncmt	cmixkzil3000244mjbi2dj8hc	Gustavo	Pelayo	Gus	\N	\N	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-08 20:56:47.146	2025-12-08 20:56:47.146
cmixnfdre000b44mj814lr455	cmixkzil3000244mjbi2dj8hc	Flo	\N	\N	\N	\N	\N	f	\N	\N	\N	2025-12-08 21:13:44.808	2025-12-08 21:13:44.808
cmiykjqiq000344lnsuaeh2e1	cmixkzil3000244mjbi2dj8hc	Almudena	\N	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.298	2025-12-09 12:40:55.298
cmiykjqiy000444lnu7axlbdn	cmixkzil3000244mjbi2dj8hc	Daniel	Sar	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.306	2025-12-09 12:40:55.306
cmiykjqj4000544lnoz4zxnmc	cmixkzil3000244mjbi2dj8hc	Ana	Sar	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.312	2025-12-09 12:40:55.312
cmiykjqjf000644ln63flreow	cmixkzil3000244mjbi2dj8hc	Carlos	Sar	\N	\N	https://blinkit.es/	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.323	2025-12-09 12:40:55.323
cmiykjqjl000744lnskuu08th	cmixkzil3000244mjbi2dj8hc	María Salud	Martín Ostos	Mariluz	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.329	2025-12-09 12:40:55.329
cmiykjqjr000844ln5w7d3w31	cmixkzil3000244mjbi2dj8hc	Begoña	López Pérez	Bego	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.335	2025-12-09 12:40:55.335
cmiykjqjx000944lnldzofe55	cmixkzil3000244mjbi2dj8hc	Nora	Oyarzabal Oyonarte	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.341	2025-12-09 12:40:55.341
cmiykjqk4000a44lndi7nrz7b	cmixkzil3000244mjbi2dj8hc	Gustavo José	Gus	Pelayo	\N	\N	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.348	2025-12-09 12:40:55.348
cmiykjqkb000b44lnduv3u2kg	cmixkzil3000244mjbi2dj8hc	Florencia	Liguri	Flo	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.355	2025-12-09 12:40:55.355
cmiykjqkg000c44lnq4mws5zg	cmixkzil3000244mjbi2dj8hc	Nicolás	Pelayo	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.36	2025-12-09 12:40:55.36
cmiykjqkm000d44ln63v581m6	cmixkzil3000244mjbi2dj8hc	Martín	Pelayo	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.366	2025-12-09 12:40:55.366
cmiykjqkt000e44lnq39zpnjd	cmixkzil3000244mjbi2dj8hc	Mario	Sánchez Arrollo	\N	\N	\N	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.373	2025-12-09 12:40:55.373
cmiykjql0000f44lnb88rr8yl	cmixkzil3000244mjbi2dj8hc	Mónica	\N	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.38	2025-12-09 12:40:55.38
cmiykjql8000g44ln5gmlzeez	cmixkzil3000244mjbi2dj8hc	Juan Pedro	Sánchez	Juanpe	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.388	2025-12-09 12:40:55.388
cmiykjqlf000h44lnpswa41iy	cmixkzil3000244mjbi2dj8hc	Ana	Van Der Sluis	\N	\N	\N	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.395	2025-12-09 12:40:55.395
cmiykjqln000i44ln9htk2b0y	cmixkzil3000244mjbi2dj8hc	Jesús	\N	\N	\N	\N	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.403	2025-12-09 12:40:55.403
cmiykjqlv000j44ln0t4u38h8	cmixkzil3000244mjbi2dj8hc	Javier	Sanz	Perli	\N	\N	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.411	2025-12-09 12:40:55.411
cmiykjqm4000k44lndnv8uth0	cmixkzil3000244mjbi2dj8hc	Ignacio	Álvarez	Nacho	\N	\N	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.42	2025-12-09 12:40:55.42
cmiykjqmc000l44lnto9zo7sj	cmixkzil3000244mjbi2dj8hc	María del Mar	Lozano	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.428	2025-12-09 12:40:55.428
cmiykjqmi000m44lnn59kngpr	cmixkzil3000244mjbi2dj8hc	Ignacio	Lozano	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.434	2025-12-09 12:40:55.434
cmiykjqmp000n44lnl4ontlyr	cmixkzil3000244mjbi2dj8hc	Ignacio Jr	Lozano	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.441	2025-12-09 12:40:55.441
cmiykjqmw000o44ln0nxnehbf	cmixkzil3000244mjbi2dj8hc	Pedro	Lozano	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.448	2025-12-09 12:40:55.448
cmiykjqn4000p44ln3mwrmxd7	cmixkzil3000244mjbi2dj8hc	Vicenç	\N	\N	\N	\N	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.456	2025-12-09 12:40:55.456
cmiykjqnc000q44lnouuajm3a	cmixkzil3000244mjbi2dj8hc	Beatriz	Mendoza	Bea	\N	\N	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.464	2025-12-09 12:40:55.464
cmiykjqnk000r44lnak4cd2rr	cmixkzil3000244mjbi2dj8hc	Rebecca	Roper	\N	\N	\N	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.472	2025-12-09 12:40:55.472
cmiykjqns000s44lno1jo6wv8	cmixkzil3000244mjbi2dj8hc	Ivan	\N	\N	\N	Es mecánico	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.48	2025-12-09 12:40:55.48
cmiykjqnz000t44lnm4w8emee	cmixkzil3000244mjbi2dj8hc	Sara	\N	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.487	2025-12-09 12:40:55.487
cmiykjqo7000u44ln0fs48khk	cmixkzil3000244mjbi2dj8hc	David 2	\N	\N	\N	Es guardia civil	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.495	2025-12-09 12:40:55.495
cmiykjqog000v44lnzxw2ivdw	cmixkzil3000244mjbi2dj8hc	David	Herrera Calleja	\N	\N	Es guardia real	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.504	2025-12-09 12:40:55.504
cmiykjqoo000w44ln7jlyceyx	cmixkzil3000244mjbi2dj8hc	Jaime	Lozano	\N	\N	https://gowmedia.es/	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.512	2025-12-09 12:40:55.512
cmiykjqow000x44lnjdmbviwo	cmixkzil3000244mjbi2dj8hc	Juan Pablo	Sotelo	Juampi	\N	\N	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.52	2025-12-09 12:40:55.52
cmiykjqp3000y44lnb85ushcp	cmixkzil3000244mjbi2dj8hc	Lucas	Gomez	\N	\N	\N	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.527	2025-12-09 12:40:55.527
cmiykjqpb000z44lntlgq9qex	cmixkzil3000244mjbi2dj8hc	Nicolás	Guevara	Chaca	\N	\N	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.535	2025-12-09 12:40:55.535
cmiykjqph001044lntjx9mixi	cmixkzil3000244mjbi2dj8hc	Matias	Guevara	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.541	2025-12-09 12:40:55.541
cmiykjqpo001144ln7l13sqnb	cmixkzil3000244mjbi2dj8hc	Gonzalo	Arteaga	Chavo	\N	\N	cmixkx0sj0006jwmj2nbuvfkm	f	\N	\N	\N	2025-12-09 12:40:55.548	2025-12-09 12:40:55.548
cmiykjqpt001244lnquywl8ef	cmixkzil3000244mjbi2dj8hc	Florencia	\N	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.553	2025-12-09 12:40:55.553
cmiykjqpz001344lnd4ima1ef	cmixkzil3000244mjbi2dj8hc	Bea	\N	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.559	2025-12-09 12:40:55.559
cmiykjqq5001444lno4xgh4xf	cmixkzil3000244mjbi2dj8hc	Romina	Barrionuevo	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.565	2025-12-09 12:40:55.565
cmiykjqqb001544lnjs4mb5ps	cmixkzil3000244mjbi2dj8hc	Santiago	Guevara	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.571	2025-12-09 12:40:55.571
cmiykjqqh001644ln9eo06rt0	cmixkzil3000244mjbi2dj8hc	Hija chaca	\N	\N	\N	Averiguar nombre	\N	f	\N	\N	\N	2025-12-09 12:40:55.577	2025-12-09 12:40:55.577
cmiykjqqn001744ln4cei8crj	cmixkzil3000244mjbi2dj8hc	Valeria	\N	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.583	2025-12-09 12:40:55.583
cmiykjqqt001844lnfg6y3otg	cmixkzil3000244mjbi2dj8hc	Vicente	\N	\N	\N	\N	\N	f	\N	\N	\N	2025-12-09 12:40:55.589	2025-12-09 12:40:55.589
\.


--
-- Data for Name: person_groups; Type: TABLE DATA; Schema: public; Owner: nametag
--

COPY public.person_groups ("personId", "groupId", "addedAt") FROM stdin;
cmixkx0ts000ejwmjsvzyfc7g	cmixkx0tc000bjwmjya5ll0bp	2025-12-08 20:03:29.007
cmixkx0ty000gjwmj9rl6gwa9	cmixkx0tc000bjwmjya5ll0bp	2025-12-08 20:03:29.013
cmixkx0u3000ijwmjkxgw63cj	cmixkx0tc000bjwmjya5ll0bp	2025-12-08 20:03:29.018
cmixkx0u9000kjwmj5c68n8u2	cmixkx0tc000bjwmjya5ll0bp	2025-12-08 20:03:29.025
cmixkx0ud000mjwmj3cq37lvu	cmixkx0te000cjwmjm6ekbv46	2025-12-08 20:03:29.029
cmixkx0uh000ojwmjoo2gclkx	cmixkx0tf000djwmjrnmcovre	2025-12-08 20:03:29.033
cmixkx0ul000qjwmjghfen95l	cmixkx0te000cjwmjm6ekbv46	2025-12-08 20:03:29.037
cmixlaiz6000544mj7xl1qqrs	cmixmexrs000644mj4wi3i3j1	2025-12-08 20:45:34.865
cmixmtkj8000a44mju9jvncmt	cmixmexrs000644mj4wi3i3j1	2025-12-08 20:56:47.146
cmixnfdre000b44mj814lr455	cmixmexrs000644mj4wi3i3j1	2025-12-08 21:13:44.808
cmixmtkj8000a44mju9jvncmt	cmiygdmqq000044lnj3bxxxoe	2025-12-09 10:44:27.422
cmixlaiz6000544mj7xl1qqrs	cmiygdmqq000044lnj3bxxxoe	2025-12-09 10:44:30.165
cmiykjqiq000344lnsuaeh2e1	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.302
cmiykjqiy000444lnu7axlbdn	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.309
cmiykjqj4000544lnoz4zxnmc	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.314
cmiykjqjf000644ln63flreow	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.326
cmiykjqjl000744lnskuu08th	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.331
cmiykjqjr000844ln5w7d3w31	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.338
cmiykjqjx000944lnldzofe55	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.344
cmiykjqk4000a44lndi7nrz7b	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.352
cmiykjqkb000b44lnduv3u2kg	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.357
cmiykjqkg000c44lnq4mws5zg	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.363
cmiykjqkm000d44ln63v581m6	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.369
cmiykjqkt000e44lnq39zpnjd	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.377
cmiykjql0000f44lnb88rr8yl	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.383
cmiykjql8000g44ln5gmlzeez	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.391
cmiykjqlf000h44lnpswa41iy	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.398
cmiykjqln000i44ln9htk2b0y	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.406
cmiykjqlv000j44ln0t4u38h8	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.414
cmiykjqm4000k44lndnv8uth0	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.424
cmiykjqmc000l44lnto9zo7sj	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.431
cmiykjqmi000m44lnn59kngpr	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.437
cmiykjqmp000n44lnl4ontlyr	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.444
cmiykjqmw000o44ln0nxnehbf	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.45
cmiykjqn4000p44ln3mwrmxd7	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.459
cmiykjqnc000q44lnouuajm3a	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.467
cmiykjqnk000r44lnak4cd2rr	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.475
cmiykjqns000s44lno1jo6wv8	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.483
cmiykjqnz000t44lnm4w8emee	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.49
cmiykjqo7000u44ln0fs48khk	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.499
cmiykjqog000v44lnzxw2ivdw	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.507
cmiykjqoo000w44ln7jlyceyx	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.515
cmiykjqow000x44lnjdmbviwo	cmiykjqil000244ln8f2rqgg4	2025-12-09 12:40:55.523
cmiykjqp3000y44lnb85ushcp	cmiykjqil000244ln8f2rqgg4	2025-12-09 12:40:55.53
cmiykjqpb000z44lntlgq9qex	cmiykjqil000244ln8f2rqgg4	2025-12-09 12:40:55.538
cmiykjqph001044lntjx9mixi	cmiykjqil000244ln8f2rqgg4	2025-12-09 12:40:55.544
cmiykjqpo001144ln7l13sqnb	cmiykjqil000244ln8f2rqgg4	2025-12-09 12:40:55.55
cmiykjqpt001244lnquywl8ef	cmiykjqil000244ln8f2rqgg4	2025-12-09 12:40:55.556
cmiykjqpz001344lnd4ima1ef	cmixmexrs000644mj4wi3i3j1	2025-12-09 12:40:55.562
cmiykjqq5001444lno4xgh4xf	cmiykjqil000244ln8f2rqgg4	2025-12-09 12:40:55.568
cmiykjqqb001544lnjs4mb5ps	cmiykjqil000244ln8f2rqgg4	2025-12-09 12:40:55.574
cmiykjqqh001644ln9eo06rt0	cmiykjqil000244ln8f2rqgg4	2025-12-09 12:40:55.58
cmiykjqqn001744ln4cei8crj	cmiykjqil000244ln8f2rqgg4	2025-12-09 12:40:55.586
cmiykjqqt001844lnfg6y3otg	cmiykjqil000244ln8f2rqgg4	2025-12-09 12:40:55.592
\.


--
-- Data for Name: relationship_types; Type: TABLE DATA; Schema: public; Owner: nametag
--

COPY public.relationship_types (id, "userId", name, label, color, "inverseId", "isDefault", "createdAt", "updatedAt") FROM stdin;
cmixkx0sl0007jwmj4s6b2lxk	\N	COLLEAGUE	Colleague	#10B981	\N	t	2025-12-08 20:03:28.965	2025-12-08 20:03:28.965
cmixkx0sn0008jwmjv5uhdsxb	\N	ACQUAINTANCE	Acquaintance	#14B8A6	\N	t	2025-12-08 20:03:28.967	2025-12-08 20:03:28.967
cmixkx0sp0009jwmjcm4l356m	\N	RELATIVE	Relative	#6366F1	\N	t	2025-12-08 20:03:28.969	2025-12-08 20:03:28.969
cmixkx0sr000ajwmjj2rmciqh	\N	OTHER	Other	#6B7280	\N	t	2025-12-08 20:03:28.971	2025-12-08 20:03:28.971
cmixkx0s70001jwmjxdzzxitq	\N	PARENT	Parent	#F59E0B	cmixkx0sa0002jwmj6r1nv9qg	t	2025-12-08 20:03:28.951	2025-12-08 20:03:28.98
cmixkx0sa0002jwmj6r1nv9qg	\N	CHILD	Child	#F59E0B	cmixkx0s70001jwmjxdzzxitq	t	2025-12-08 20:03:28.954	2025-12-08 20:03:28.983
cmixkx0sd0003jwmj9nh201wy	\N	SIBLING	Sibling	#8B5CF6	cmixkx0sd0003jwmj9nh201wy	t	2025-12-08 20:03:28.957	2025-12-08 20:03:28.984
cmixkx0sf0004jwmj9a2835l1	\N	SPOUSE	Spouse	#EC4899	cmixkx0sf0004jwmj9a2835l1	t	2025-12-08 20:03:28.959	2025-12-08 20:03:28.986
cmixkx0sh0005jwmjvdxx6dde	\N	PARTNER	Partner	#EC4899	cmixkx0sh0005jwmjvdxx6dde	t	2025-12-08 20:03:28.961	2025-12-08 20:03:28.987
cmixkx0sj0006jwmj2nbuvfkm	\N	FRIEND	Friend	#3B82F6	cmixkx0sj0006jwmj2nbuvfkm	t	2025-12-08 20:03:28.963	2025-12-08 20:03:28.989
cmixl0pdc000344mjlsshm44k	cmixkzil3000244mjbi2dj8hc	TEST1	Test1	#EF4444	\N	f	2025-12-08 20:06:20.784	2025-12-08 20:06:20.784
cmixl9ki9000444mj76ysgxh8	cmixkzil3000244mjbi2dj8hc	SIGNIFICANT_OTHER	Significant Other	#8B5CF6	cmixl9ki9000444mj76ysgxh8	f	2025-12-08 20:13:14.385	2025-12-08 20:13:14.389
\.


--
-- Data for Name: relationships; Type: TABLE DATA; Schema: public; Owner: nametag
--

COPY public.relationships (id, "personId", "relatedPersonId", "relationshipTypeId", notes, "createdAt", "updatedAt") FROM stdin;
cmixkx0us000sjwmj16yusqed	cmixkx0ts000ejwmjsvzyfc7g	cmixkx0ty000gjwmj9rl6gwa9	cmixkx0sf0004jwmj9a2835l1	Married since 2010	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixkx0us000tjwmjhrvevy0m	cmixkx0ts000ejwmjsvzyfc7g	cmixkx0u3000ijwmjkxgw63cj	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixkx0us000ujwmjdlfwl082	cmixkx0ts000ejwmjsvzyfc7g	cmixkx0u9000kjwmj5c68n8u2	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixkx0us000vjwmjbxx46oa8	cmixkx0ts000ejwmjsvzyfc7g	cmixkx0ud000mjwmj3cq37lvu	cmixkx0sj0006jwmj2nbuvfkm	\N	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixkx0us000wjwmj38uva3vn	cmixkx0ty000gjwmj9rl6gwa9	cmixkx0ts000ejwmjsvzyfc7g	cmixkx0sf0004jwmj9a2835l1	Married since 2010	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixkx0us000xjwmjzu1trg84	cmixkx0ty000gjwmj9rl6gwa9	cmixkx0u3000ijwmjkxgw63cj	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixkx0us000yjwmjqlcu92xf	cmixkx0ty000gjwmj9rl6gwa9	cmixkx0u9000kjwmj5c68n8u2	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixkx0us000zjwmjwwbpjmze	cmixkx0u3000ijwmjkxgw63cj	cmixkx0ts000ejwmjsvzyfc7g	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixkx0us0010jwmjoqvwnpbr	cmixkx0u3000ijwmjkxgw63cj	cmixkx0ty000gjwmj9rl6gwa9	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixkx0us0011jwmjy0j3f45e	cmixkx0u3000ijwmjkxgw63cj	cmixkx0u9000kjwmj5c68n8u2	cmixkx0sd0003jwmj9nh201wy	\N	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixkx0us0012jwmjj8wiqte3	cmixkx0u9000kjwmj5c68n8u2	cmixkx0ts000ejwmjsvzyfc7g	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixkx0us0013jwmjte96ocsj	cmixkx0u9000kjwmj5c68n8u2	cmixkx0ty000gjwmj9rl6gwa9	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixkx0us0014jwmj08qfgw02	cmixkx0u9000kjwmj5c68n8u2	cmixkx0u3000ijwmjkxgw63cj	cmixkx0sd0003jwmj9nh201wy	\N	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixkx0us0015jwmj1sfmpnpm	cmixkx0ud000mjwmj3cq37lvu	cmixkx0ts000ejwmjsvzyfc7g	cmixkx0sj0006jwmj2nbuvfkm	\N	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixkx0us0016jwmj9b54i7lo	cmixkx0uh000ojwmjoo2gclkx	cmixkx0ud000mjwmj3cq37lvu	cmixkx0sl0007jwmj4s6b2lxk	\N	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixkx0us0017jwmjykt8ti20	cmixkx0ul000qjwmjghfen95l	cmixkx0ts000ejwmjsvzyfc7g	cmixkx0sj0006jwmj2nbuvfkm	\N	2025-12-08 20:03:29.044	2025-12-08 20:03:29.044
cmixnfdrp000c44mjv4vb76mc	cmixnfdre000b44mj814lr455	cmixmtkj8000a44mju9jvncmt	cmixl9ki9000444mj76ysgxh8	\N	2025-12-08 21:13:44.821	2025-12-08 21:13:44.821
cmixnfdrr000d44mjijbzquag	cmixmtkj8000a44mju9jvncmt	cmixnfdre000b44mj814lr455	cmixl9ki9000444mj76ysgxh8	\N	2025-12-08 21:13:44.823	2025-12-08 21:13:44.823
cmiykjqr0001944lnv1s2iwor	cmiykjqiq000344lnsuaeh2e1	cmiykjqlv000j44ln0t4u38h8	cmixkx0sf0004jwmj9a2835l1	\N	2025-12-09 12:40:55.596	2025-12-09 12:40:55.596
cmiykjqr5001a44ln8cn9tbj1	cmiykjqiy000444lnu7axlbdn	cmiykjqjf000644ln63flreow	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-09 12:40:55.601	2025-12-09 12:40:55.601
cmiykjqra001b44lnf4lahgh4	cmiykjqiy000444lnu7axlbdn	cmiykjqjr000844ln5w7d3w31	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-09 12:40:55.606	2025-12-09 12:40:55.606
cmiykjqre001c44ln6xsvlvly	cmiykjqj4000544lnoz4zxnmc	cmiykjqjf000644ln63flreow	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-09 12:40:55.61	2025-12-09 12:40:55.61
cmiykjqrh001d44lnypdohl5w	cmiykjqj4000544lnoz4zxnmc	cmiykjqjr000844ln5w7d3w31	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-09 12:40:55.613	2025-12-09 12:40:55.613
cmiykjqrl001e44lnsdbbd5q7	cmiykjqjf000644ln63flreow	cmiykjqjr000844ln5w7d3w31	cmixkx0sf0004jwmj9a2835l1	\N	2025-12-09 12:40:55.617	2025-12-09 12:40:55.617
cmiykjqrp001f44lnfn3adj77	cmiykjqjf000644ln63flreow	cmiykjqiy000444lnu7axlbdn	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-09 12:40:55.621	2025-12-09 12:40:55.621
cmiykjqrt001g44lnumac56or	cmiykjqjf000644ln63flreow	cmiykjqj4000544lnoz4zxnmc	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-09 12:40:55.625	2025-12-09 12:40:55.625
cmiykjqrx001h44lnp8d0zyrr	cmiykjqjl000744lnskuu08th	cmixlaiz6000544mj7xl1qqrs	cmixl9ki9000444mj76ysgxh8	\N	2025-12-09 12:40:55.629	2025-12-09 12:40:55.629
cmiykjqs1001i44ln1kzsdmfx	cmiykjqjr000844ln5w7d3w31	cmiykjqjf000644ln63flreow	cmixkx0sf0004jwmj9a2835l1	\N	2025-12-09 12:40:55.633	2025-12-09 12:40:55.633
cmiykjqs5001j44ln1w3jahs7	cmiykjqjr000844ln5w7d3w31	cmiykjqj4000544lnoz4zxnmc	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-09 12:40:55.637	2025-12-09 12:40:55.637
cmiykjqs9001k44lnbk2vn8my	cmiykjqjr000844ln5w7d3w31	cmiykjqiy000444lnu7axlbdn	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-09 12:40:55.641	2025-12-09 12:40:55.641
cmiykjqsd001l44lnzp0lyufc	cmiykjqjx000944lnldzofe55	cmiykjqoo000w44ln7jlyceyx	cmixkx0sf0004jwmj9a2835l1	\N	2025-12-09 12:40:55.645	2025-12-09 12:40:55.645
cmiykjqsg001m44lncn9fcc9i	cmiykjqk4000a44lndi7nrz7b	cmiykjqkb000b44lnduv3u2kg	cmixkx0sf0004jwmj9a2835l1	\N	2025-12-09 12:40:55.648	2025-12-09 12:40:55.648
cmiykjqsk001n44ln63z0kmdo	cmiykjqk4000a44lndi7nrz7b	cmiykjqkg000c44lnq4mws5zg	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-09 12:40:55.652	2025-12-09 12:40:55.652
cmiykjqso001o44lnb03uozcz	cmiykjqk4000a44lndi7nrz7b	cmiykjqkm000d44ln63v581m6	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-09 12:40:55.656	2025-12-09 12:40:55.656
cmiykjqsu001p44lnopy09pfk	cmiykjqkb000b44lnduv3u2kg	cmiykjqk4000a44lndi7nrz7b	cmixkx0sf0004jwmj9a2835l1	\N	2025-12-09 12:40:55.662	2025-12-09 12:40:55.662
cmiykjqt0001q44lnepwxyc3v	cmiykjqkb000b44lnduv3u2kg	cmiykjqkm000d44ln63v581m6	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-09 12:40:55.668	2025-12-09 12:40:55.668
cmiykjqt5001r44lnl3q2qvg5	cmiykjqkb000b44lnduv3u2kg	cmiykjqkg000c44lnq4mws5zg	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-09 12:40:55.673	2025-12-09 12:40:55.673
cmiykjqta001s44lnqwbfhzve	cmiykjqkg000c44lnq4mws5zg	cmiykjqk4000a44lndi7nrz7b	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-09 12:40:55.678	2025-12-09 12:40:55.678
cmiykjqtg001t44lni59weick	cmiykjqkg000c44lnq4mws5zg	cmiykjqkb000b44lnduv3u2kg	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-09 12:40:55.684	2025-12-09 12:40:55.684
cmiykjqtl001u44ln4x12laeo	cmiykjqkm000d44ln63v581m6	cmiykjqk4000a44lndi7nrz7b	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-09 12:40:55.689	2025-12-09 12:40:55.689
cmiykjqtz001v44ln7bovp6dx	cmiykjqkm000d44ln63v581m6	cmiykjqkb000b44lnduv3u2kg	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-09 12:40:55.703	2025-12-09 12:40:55.703
cmiykjqu3001w44lnqdyhmk5s	cmiykjqkt000e44lnq39zpnjd	cmiykjql8000g44ln5gmlzeez	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-09 12:40:55.707	2025-12-09 12:40:55.707
cmiykjqu7001x44ln5hzn5ony	cmiykjql0000f44lnb88rr8yl	cmiykjqkt000e44lnq39zpnjd	cmixl9ki9000444mj76ysgxh8	\N	2025-12-09 12:40:55.711	2025-12-09 12:40:55.711
cmiykjqub001y44lnd3jjjq1z	cmiykjql8000g44ln5gmlzeez	cmiykjqkt000e44lnq39zpnjd	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-09 12:40:55.715	2025-12-09 12:40:55.715
cmiykjquf001z44lnkuygaysr	cmiykjqln000i44ln9htk2b0y	cmiykjqlf000h44lnpswa41iy	cmixl9ki9000444mj76ysgxh8	\N	2025-12-09 12:40:55.719	2025-12-09 12:40:55.719
cmiykjquj002044ln5d7fpt37	cmiykjqlv000j44ln0t4u38h8	cmiykjqiq000344lnsuaeh2e1	cmixkx0sf0004jwmj9a2835l1	\N	2025-12-09 12:40:55.723	2025-12-09 12:40:55.723
cmiykjqun002144ln2lgfwc5b	cmiykjqmc000l44lnto9zo7sj	cmiykjqoo000w44ln7jlyceyx	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-09 12:40:55.727	2025-12-09 12:40:55.727
cmiykjqur002244lncoxxh5oo	cmiykjqmi000m44lnn59kngpr	cmiykjqoo000w44ln7jlyceyx	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-09 12:40:55.731	2025-12-09 12:40:55.731
cmiykjquu002344lneckie64k	cmiykjqmp000n44lnl4ontlyr	cmiykjqoo000w44ln7jlyceyx	cmixkx0sd0003jwmj9nh201wy	\N	2025-12-09 12:40:55.734	2025-12-09 12:40:55.734
cmiykjquy002444lnkm3vl2cq	cmiykjqmw000o44ln0nxnehbf	cmiykjqoo000w44ln7jlyceyx	cmixkx0sd0003jwmj9nh201wy	\N	2025-12-09 12:40:55.738	2025-12-09 12:40:55.738
cmiykjqv2002544lnguhtu8wm	cmiykjqns000s44lno1jo6wv8	cmiykjqnz000t44lnm4w8emee	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-09 12:40:55.742	2025-12-09 12:40:55.742
cmiykjqv6002644lnbu97ryef	cmiykjqns000s44lno1jo6wv8	cmiykjqpz001344lnd4ima1ef	cmixkx0sf0004jwmj9a2835l1	\N	2025-12-09 12:40:55.746	2025-12-09 12:40:55.746
cmiykjqv9002744lnoudfxrlo	cmiykjqnz000t44lnm4w8emee	cmiykjqns000s44lno1jo6wv8	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-09 12:40:55.749	2025-12-09 12:40:55.749
cmiykjqve002844ln3rjjmald	cmiykjqoo000w44ln7jlyceyx	cmiykjqjx000944lnldzofe55	cmixkx0sf0004jwmj9a2835l1	\N	2025-12-09 12:40:55.754	2025-12-09 12:40:55.754
cmiykjqvh002944ln86lbhdoy	cmiykjqoo000w44ln7jlyceyx	cmiykjqmc000l44lnto9zo7sj	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-09 12:40:55.757	2025-12-09 12:40:55.757
cmiykjqvl002a44lnygkphm5o	cmiykjqoo000w44ln7jlyceyx	cmiykjqmi000m44lnn59kngpr	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-09 12:40:55.761	2025-12-09 12:40:55.761
cmiykjqvp002b44lngzhd3m9y	cmiykjqoo000w44ln7jlyceyx	cmiykjqmp000n44lnl4ontlyr	cmixkx0sd0003jwmj9nh201wy	\N	2025-12-09 12:40:55.765	2025-12-09 12:40:55.765
cmiykjqvt002c44lnvkx6bqhc	cmiykjqoo000w44ln7jlyceyx	cmiykjqmw000o44ln0nxnehbf	cmixkx0sd0003jwmj9nh201wy	\N	2025-12-09 12:40:55.769	2025-12-09 12:40:55.769
cmiykjqvx002d44ln9zo80opt	cmiykjqow000x44lnjdmbviwo	cmiykjqqn001744ln4cei8crj	cmixkx0sf0004jwmj9a2835l1	\N	2025-12-09 12:40:55.773	2025-12-09 12:40:55.773
cmiykjqw3002e44lnkrf879my	cmiykjqow000x44lnjdmbviwo	cmiykjqqt001844lnfg6y3otg	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-09 12:40:55.779	2025-12-09 12:40:55.779
cmiykjqw7002f44lnms5psuy3	cmiykjqpb000z44lntlgq9qex	cmiykjqph001044lntjx9mixi	cmixkx0sd0003jwmj9nh201wy	\N	2025-12-09 12:40:55.783	2025-12-09 12:40:55.783
cmiykjqwb002g44lnlisdwbf6	cmiykjqpb000z44lntlgq9qex	cmiykjqq5001444lno4xgh4xf	cmixkx0sf0004jwmj9a2835l1	\N	2025-12-09 12:40:55.787	2025-12-09 12:40:55.787
cmiykjqwe002h44lnfncsv9fc	cmiykjqpb000z44lntlgq9qex	cmiykjqqb001544lnjs4mb5ps	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-09 12:40:55.79	2025-12-09 12:40:55.79
cmiykjqwi002i44lnhwtqf3kj	cmiykjqpb000z44lntlgq9qex	cmiykjqqh001644ln9eo06rt0	cmixkx0s70001jwmjxdzzxitq	\N	2025-12-09 12:40:55.794	2025-12-09 12:40:55.794
cmiykjqwl002j44lnyrdo7oah	cmiykjqph001044lntjx9mixi	cmiykjqpb000z44lntlgq9qex	cmixkx0sd0003jwmj9nh201wy	\N	2025-12-09 12:40:55.797	2025-12-09 12:40:55.797
cmiykjqwp002k44lny9e4sagk	cmiykjqpt001244lnquywl8ef	cmiykjqpo001144ln7l13sqnb	cmixl9ki9000444mj76ysgxh8	\N	2025-12-09 12:40:55.801	2025-12-09 12:40:55.801
cmiykjqwt002l44lnu09fk2k4	cmiykjqpz001344lnd4ima1ef	cmiykjqns000s44lno1jo6wv8	cmixkx0sf0004jwmj9a2835l1	\N	2025-12-09 12:40:55.805	2025-12-09 12:40:55.805
cmiykjqwx002m44lnzjl1krgn	cmiykjqq5001444lno4xgh4xf	cmiykjqpb000z44lntlgq9qex	cmixkx0sf0004jwmj9a2835l1	\N	2025-12-09 12:40:55.809	2025-12-09 12:40:55.809
cmiykjqx1002n44ln8qidbep4	cmiykjqqb001544lnjs4mb5ps	cmiykjqpb000z44lntlgq9qex	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-09 12:40:55.813	2025-12-09 12:40:55.813
cmiykjqx4002o44ln77eg6zca	cmiykjqqh001644ln9eo06rt0	cmiykjqpb000z44lntlgq9qex	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-09 12:40:55.816	2025-12-09 12:40:55.816
cmiykjqx8002p44ln5wipk8v5	cmiykjqqn001744ln4cei8crj	cmiykjqow000x44lnjdmbviwo	cmixkx0sf0004jwmj9a2835l1	\N	2025-12-09 12:40:55.82	2025-12-09 12:40:55.82
cmiykjqxb002q44lnbspj3k5i	cmiykjqqt001844lnfg6y3otg	cmiykjqow000x44lnjdmbviwo	cmixkx0sa0002jwmj6r1nv9qg	\N	2025-12-09 12:40:55.823	2025-12-09 12:40:55.823
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: nametag
--

COPY public.users (id, email, password, name, surname, nickname, theme, "dateFormat", "emailVerified", "emailVerifyToken", "emailVerifyExpires", "emailVerifySentAt", "passwordResetToken", "passwordResetExpires", "passwordResetSentAt", "createdAt", "updatedAt") FROM stdin;
cmixkx0s10000jwmjo82b5r2w	demo@nametag.one	$2b$10$ttaXH//hJnGVXL3KySAk0uFU8YQdNMaNIFt4my/d3903pRdXOvbie	Demo User	\N	\N	LIGHT	MDY	f	\N	\N	\N	\N	\N	\N	2025-12-08 20:03:28.945	2025-12-08 20:03:28.945
cmixkzil3000244mjbi2dj8hc	mattogodoy@gmail.com	$2b$10$7Km68bYFoBmXcO/fUPK6sOZkKc8mq9t6DuqWfna9.CALnVgmXA0H6	Matias	\N	\N	DARK	MDY	t	\N	\N	2025-12-08 20:05:25.334	\N	\N	\N	2025-12-08 20:05:25.335	2025-12-08 20:05:47.804
cmiz6j1yc000001t4e9xew9ip	test1765320974@example.com	$2b$10$oiwvd/mcUdQCIukHzRPNMu5oe/jEsfAg.qmO7BYfKTz9jFfjihhvy	Test	User	\N	DARK	MDY	f	7a97b295074a672b9db9dab5398338c762c6af7f4c5a5ad3c3f461f5613f9aed	2025-12-10 22:56:15.004	2025-12-09 22:56:15.004	\N	\N	\N	2025-12-09 22:56:15.012	2025-12-09 22:56:15.012
cmiz6lbzg000001t4dtn1o2zc	test1765321081@example.com	$2b$10$.5KyRjRwU2B82GK8j96tiuPaSxWxqA6j.UOE.VTlq3wSJW6zboIO2	Test	User	\N	DARK	MDY	f	3d0ec54b89455538244e2b8d365e7834cc9ed01a5aa2635e4514eb90e7d48e71	2025-12-10 22:58:01.316	2025-12-09 22:58:01.316	\N	\N	\N	2025-12-09 22:58:01.324	2025-12-09 22:58:01.324
cmiz6nj1p000001t4h8m312eo	test1765321183@example.com	$2b$10$FbhCcajzq4UZ5OKaVS4GLejHn8GBfpQn9oAUpTY4D11RFfQ6jzk/6	Test	User	\N	DARK	MDY	f	80e645c8c3eee2fde8f6ef75ca98d30095e9e635ed30939fa210b68a673eb8b0	2025-12-10 22:59:43.781	2025-12-09 22:59:43.781	\N	\N	\N	2025-12-09 22:59:43.789	2025-12-09 22:59:43.789
cmiz6ptpq000001t4qt7cwmen	test1765321290@example.com	$2b$10$vCvMTQk3oLEdZ5f0q1QbdObMoz6DebyzJJSbr195PZRsNduJZjlmy	Test	User	\N	DARK	MDY	f	c1a0821a5c7a01172f1b483b58d85dea1119397c0f2871a414b920850e647981	2025-12-10 23:01:30.918	2025-12-09 23:01:30.918	\N	\N	\N	2025-12-09 23:01:30.926	2025-12-09 23:01:30.926
cmiz6t0ay000001o3lj2i37ei	finaltest1765321439@example.com	$2b$10$NDqPGDB/zRqaSFWHQib3NOqrbrB7g5ISBHr4n0NROPoQyfasClVai	Final	Test	\N	DARK	MDY	f	b6d176d4f7c8bf37738f10ead9f5303d73ce71284d20b4582ec462419b7754c1	2025-12-10 23:03:59.426	2025-12-09 23:03:59.426	\N	\N	\N	2025-12-09 23:03:59.434	2025-12-09 23:03:59.434
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: important_dates important_dates_pkey; Type: CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.important_dates
    ADD CONSTRAINT important_dates_pkey PRIMARY KEY (id);


--
-- Name: people people_pkey; Type: CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.people
    ADD CONSTRAINT people_pkey PRIMARY KEY (id);


--
-- Name: person_groups person_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.person_groups
    ADD CONSTRAINT person_groups_pkey PRIMARY KEY ("personId", "groupId");


--
-- Name: relationship_types relationship_types_pkey; Type: CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.relationship_types
    ADD CONSTRAINT relationship_types_pkey PRIMARY KEY (id);


--
-- Name: relationships relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.relationships
    ADD CONSTRAINT relationships_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: groups_userId_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "groups_userId_idx" ON public.groups USING btree ("userId");


--
-- Name: important_dates_personId_date_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "important_dates_personId_date_idx" ON public.important_dates USING btree ("personId", date);


--
-- Name: important_dates_personId_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "important_dates_personId_idx" ON public.important_dates USING btree ("personId");


--
-- Name: important_dates_reminderEnabled_date_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "important_dates_reminderEnabled_date_idx" ON public.important_dates USING btree ("reminderEnabled", date);


--
-- Name: people_contactReminderEnabled_lastContact_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "people_contactReminderEnabled_lastContact_idx" ON public.people USING btree ("contactReminderEnabled", "lastContact");


--
-- Name: people_relationshipToUserId_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "people_relationshipToUserId_idx" ON public.people USING btree ("relationshipToUserId");


--
-- Name: people_userId_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "people_userId_idx" ON public.people USING btree ("userId");


--
-- Name: people_userId_lastContact_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "people_userId_lastContact_idx" ON public.people USING btree ("userId", "lastContact");


--
-- Name: people_userId_name_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "people_userId_name_idx" ON public.people USING btree ("userId", name);


--
-- Name: people_userId_nickname_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "people_userId_nickname_idx" ON public.people USING btree ("userId", nickname);


--
-- Name: people_userId_surname_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "people_userId_surname_idx" ON public.people USING btree ("userId", surname);


--
-- Name: person_groups_groupId_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "person_groups_groupId_idx" ON public.person_groups USING btree ("groupId");


--
-- Name: person_groups_personId_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "person_groups_personId_idx" ON public.person_groups USING btree ("personId");


--
-- Name: relationship_types_userId_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "relationship_types_userId_idx" ON public.relationship_types USING btree ("userId");


--
-- Name: relationships_personId_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "relationships_personId_idx" ON public.relationships USING btree ("personId");


--
-- Name: relationships_relatedPersonId_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "relationships_relatedPersonId_idx" ON public.relationships USING btree ("relatedPersonId");


--
-- Name: relationships_relationshipTypeId_idx; Type: INDEX; Schema: public; Owner: nametag
--

CREATE INDEX "relationships_relationshipTypeId_idx" ON public.relationships USING btree ("relationshipTypeId");


--
-- Name: users_emailVerifyToken_key; Type: INDEX; Schema: public; Owner: nametag
--

CREATE UNIQUE INDEX "users_emailVerifyToken_key" ON public.users USING btree ("emailVerifyToken");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: nametag
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_passwordResetToken_key; Type: INDEX; Schema: public; Owner: nametag
--

CREATE UNIQUE INDEX "users_passwordResetToken_key" ON public.users USING btree ("passwordResetToken");


--
-- Name: groups groups_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT "groups_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: important_dates important_dates_personId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.important_dates
    ADD CONSTRAINT "important_dates_personId_fkey" FOREIGN KEY ("personId") REFERENCES public.people(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: people people_relationshipToUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.people
    ADD CONSTRAINT "people_relationshipToUserId_fkey" FOREIGN KEY ("relationshipToUserId") REFERENCES public.relationship_types(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: people people_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.people
    ADD CONSTRAINT "people_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: person_groups person_groups_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.person_groups
    ADD CONSTRAINT "person_groups_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: person_groups person_groups_personId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.person_groups
    ADD CONSTRAINT "person_groups_personId_fkey" FOREIGN KEY ("personId") REFERENCES public.people(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: relationship_types relationship_types_inverseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.relationship_types
    ADD CONSTRAINT "relationship_types_inverseId_fkey" FOREIGN KEY ("inverseId") REFERENCES public.relationship_types(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: relationship_types relationship_types_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.relationship_types
    ADD CONSTRAINT "relationship_types_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: relationships relationships_personId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.relationships
    ADD CONSTRAINT "relationships_personId_fkey" FOREIGN KEY ("personId") REFERENCES public.people(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: relationships relationships_relatedPersonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.relationships
    ADD CONSTRAINT "relationships_relatedPersonId_fkey" FOREIGN KEY ("relatedPersonId") REFERENCES public.people(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: relationships relationships_relationshipTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nametag
--

ALTER TABLE ONLY public.relationships
    ADD CONSTRAINT "relationships_relationshipTypeId_fkey" FOREIGN KEY ("relationshipTypeId") REFERENCES public.relationship_types(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 9sLqRyR9EUNpru83WZwaSclivYt8O1l6JocKfk9mc2WhwJ4OSwfbeN6H87KsU7D

